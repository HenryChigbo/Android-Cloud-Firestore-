package com.inducesmile.firestoreexample.utils;

public class Constants {


    private  Constants() {
    }


    public static final int SPLASH_TIME = 2000;
}
