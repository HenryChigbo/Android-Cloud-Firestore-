package com.inducesmile.firestoreexample.login;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.inducesmile.firestoreexample.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
